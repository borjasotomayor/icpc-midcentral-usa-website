#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

FILE *finput;
FILE *foutput;
int  cin, lahead;

int fpeek(FILE *stream)
{
  int c;

  c = fgetc(stream);
  ungetc(c,stream);

  return c;
}

main()
{
  if ((finput = fopen("MARKUP.IN", "r")) == NULL) {
    printf("Error: MARKUP.IN could not be opened for input.\n");
    exit(1);
  }

  if ((foutput = fopen("MARKUP.OUT", "w")) == NULL) {
    printf("Error: MARKUP.OUT could not be opened for output.\n");
    exit(2);
  }

  while ((cin = fgetc(finput)) != EOF) {

    lahead = fpeek(finput);

    if (cin == '\\' ) {
      if (lahead == 'b' || lahead == 'i') {
   cin = fgetc(finput);
      } else if (lahead == '*') {
   cin = fgetc(finput);
   while ((cin = fgetc(finput)) != EOF &&
          (cin != '\\' || (cin == '\\' && fpeek(finput) != '*')))
     fputc(cin, foutput);
   if (fpeek(finput) == '*')
     cin = fgetc(finput);
      } else if (lahead == 's') {
   cin = fgetc(finput);
   while ((cin = fgetc(finput)) != EOF && isdigit(cin))
     /* empty */;
   if (cin != EOF && cin != '.')
     ungetc(cin, finput);
   while ((cin = fgetc(finput)) != EOF && isdigit(cin))
     /* empty */;
   if (cin != EOF)
     ungetc(cin, finput);
      } else if (lahead != EOF) {
   cin = fgetc(finput);
   fputc(cin, foutput);
      }
    } else
      fputc(cin, foutput);
  }

  fclose(finput);
  fclose(foutput);
  return 0;
}
