This directory gets backups of all submissions.
