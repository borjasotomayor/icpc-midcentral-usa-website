#!/usr/bin/env python3
'nine knights'
import sys

s = sys.stdin.read()
valid = s.count('k') == 9
if valid:
    board = ['.'*9] *2 + ['..' + line + '..' for line in s.splitlines()]
    mvs = [(-1, -2), (-2, -1), (-1, 2), (-2, 1)] # to previous rows
    for r in range(2,7):
         for c in range(2,7):
             if board[r][c] == 'k':
                 for dr, dc in mvs:
                     if board[r+dr][c+dc] == 'k':
                         valid = False        
print('valid' if valid else 'invalid')
                
