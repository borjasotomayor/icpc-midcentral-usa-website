#!/usr/bin/env python3
'faulty robot'
import sys

##s = '''7 9
##1 2
##2 3
##-1 5
##2 6
##5 1
##-4 1
##5 6
##-6 7
##-5 4
##'''
##s ='''3 2
##1 2
##1 3
##'''
s = sys.stdin.read()
n, w, *edgeData = map(int, s.split())
np = n+1
nb = [[] for i in range(np)] # neighbors of node i, start from 1
NEW, JUMPED, NOJUMP = 0, 1, 2 # codes for previous access to node
vis = [NEW] * np # initially no node visited
to = [False]*np # forced move destination, initially none
ends = 0 # count ending places

def go(n, visCode): # to n, visCode shows if jumped already
    global ends
    if vis[n] < visCode: # either change NEW, or change JUMPED to NOJUMP
        if not to[n] and not vis[n]:
            ends += 1
        vis[n] = visCode
        if to[n]: # no further random jump needed
            go(to[n], visCode)
        if visCode  == NOJUMP:
           for i in nb[n]: # have your 1 random jump
               go(i, JUMPED)

for i in range(0, 2*w, 2):
    a = edgeData[i]
    b = edgeData[i+1]
    if a < 0:
        to[-a] = b
    else:
        nb[a].append(b)
go(1, NOJUMP) # NOJUMP to start at 1.  See where you go... recursion depth
print(ends) #   is no more than # forces + 1; less than Python 975 limit

