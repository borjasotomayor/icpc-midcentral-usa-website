#!/usr/bin/env python3
tok = input().split()
print('yes' if len(tok) == len(set(tok)) else 'no')
