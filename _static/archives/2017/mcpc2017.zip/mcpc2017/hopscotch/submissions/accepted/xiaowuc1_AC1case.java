import java.io.*;
import java.util.*;
public class xiaowuc1_AC1case {
  public static void main(String[] args) throws IOException {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    StringTokenizer st = new StringTokenizer(br.readLine());
    int n = Integer.parseInt(st.nextToken());
    int x = Integer.parseInt(st.nextToken());
    int y = Integer.parseInt(st.nextToken());
    long ret = 0;
    for(int k = 1; k <= Math.min(n/x, n/y); k++) {
      ret += numWays(n - k*x, k) * 1L * numWays(n - k*y, k);
      ret %= MOD;
    }
    System.out.println(ret);
  }

  public static int numWays(int n, int k) {
    long ret = fact[n+k-1];
    ret *= factInv[k-1];
    ret %= MOD;
    ret *= factInv[n];
    ret %= MOD;
    return (int)ret;
  }

  static int[] fact;
  static int[] factInv;
  static final int MOD = 1000000007;
  public static int modpow(long b, long e, long m) {
    long r = 1;
    while(e > 0) {
      if(e%2 == 1) {
        r *= b;
        r %= m;
      }
      b *= b;
      b %= m;
      e /= 2;
    }
    return (int)r;
  }
  static {
    fact = new int[2100000];
    factInv = new int[fact.length];
    fact[0] = 1;
    for(int i = 1; i < fact.length; i++) {
      fact[i] = (int)((fact[i-1] * (long)(i)) % MOD);
    }
    factInv[factInv.length-1] = modpow(fact[fact.length-1], MOD-2, MOD);
    for(int i = factInv.length-2; i >= 0; i--) {
      factInv[i] = (int)((factInv[i+1] * (i+1L))%MOD);
    }
  }
}
