#!/usr/bin/env python3
'''hopscotch'''

def numWays(n, k): # choose n from n+k-1 = count ways k nonneg ints add to n
    return fact[n+k-1]*factinv[k-1]%p*factinv[n]%p

p = 10**9 + 7
n, x, y = map(int, input().split())
SIZE = 2*n+2 # size of factorial list, need fact[n+k-1]
fact =[1] # 0!
for i in range(1, SIZE): 
    fact.append(fact[-1]*i % p)
factinv = [pow(fact[-1], p-2, p)] #finite p group (*) inverse of big factorial
for i in range(SIZE-1, 0, -1):   # avoid more powers:  multiplying to remove   
    factinv.append(factinv[-1]*i%p) #    largest inv factor for next inv
factinv.reverse()
ret = 0
for k in range(1, min(n//x, n//y)+1):
    ret += numWays(n - k*x, k) * numWays(n - k*y, k)
    ret %= p
print(ret)
