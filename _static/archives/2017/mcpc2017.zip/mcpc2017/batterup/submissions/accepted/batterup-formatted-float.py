#!/usr/bin/python3

#
# Autumn 2017
#

import sys

def solve(at_bat_results):
    total_bases = 0
    official_at_bats = 0

    # Iterate through the at bats
    for at_bat in at_bat_results:
        # Valid input is in range []-1..4]
        assert(at_bat >= -1)
        assert(at_bat < 5)

        # Tally official at-bats statistics
        if at_bat > -1:
            official_at_bats += 1
            total_bases += at_bat

    # Calculate the slugging percentage
    return total_bases/official_at_bats

if __name__ == "__main__":
    # Read fomatted line from standard in
    tokens = sys.stdin.read().split()

    ntokens = int(tokens.pop(0))

    assert(ntokens == len(tokens))

    at_bat_results = [int(x) for x in tokens]

    print("{:.4f}".format(solve(at_bat_results)))

