#!/usr/bin/env python3
a = 'X' + input() +'Y' # add sentenals
b = 'Z' + input() +'Z'
i = 1
while a[i] == b[i]:
    i += 1
j = len(a) - 2
while a[j] == b[j]:
    j -= 1
if  ''.join(reversed(a[i:j+1])) != b[i:j+1]:
    print(0)
else:
    n = 1
    while a[i-n] == a[j+n]:
        n += 1
    print(n)
