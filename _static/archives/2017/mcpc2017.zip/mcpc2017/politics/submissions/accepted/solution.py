#!/usr/bin/env python3

from collections import defaultdict

maxt = 2000010
n = int(input())
tasks = defaultdict(list)
for i in range(n):
	t,a,b, = map(int,input().split())
	tasks[t].append((a,b))

ans = [0.0 for _ in range(maxt+1)]
suff_ans = [0.0 for _ in range(maxt+1)]
for i in range(maxt-1, -1, -1):
	ans[i] = ans[i+1]
	for (a,b) in tasks[i]:
		ans[i] = max(ans[i], 1 + (suff_ans[i+a] - suff_ans[i+b+1]) / (b - a + 1))
	suff_ans[i] = suff_ans[i+1] + ans[i]

print(ans[0])
