/* Turbo C solution to "Lost in Space" */

#include <stdio.h>
#include <string.h>

const int FALSE=0;
const int TRUE=-1;
char SearchString[50];
char Space [50][50];
int Row, Col;
FILE *InputFile, *OutputFile;

void Check(int rw, int cl, int dir, int *match)
{
  unsigned int i;
  char *DirStr;

if(SearchString[0] != Space[rw][cl])
  {
    *match = FALSE;
    return;
  }
  for (i=0; i<strlen(SearchString); i++)
  {
    while (Space[rw][cl]==' ')
    {
      switch (dir)
      {
        case 1 : rw--; break;
        case 2 : rw--; cl++; break;
        case 3 : cl++; break;
        case 4 : rw++; cl++; break;
        case 5 : rw++; break;
        case 6 : rw++; cl--; break;
        case 7 : cl--; break;
        case 8 : rw--; cl--; break;
      }
    }
    if (Space[rw][cl]!=SearchString[i])
    {
      *match = FALSE;
      return;
    }
    switch (dir)
    {
      case 1 : rw--; break;
      case 2 : rw--; cl++; break;
      case 3 : cl++; break;
      case 4 : rw++; cl++; break;
      case 5 : rw++; break;
      case 6 : rw++; cl--; break;
      case 7 : cl--; break;
      case 8 : rw--; cl--; break;
    }
  }
      switch (dir)
      {
        case 1 : DirStr="N"; break;
        case 2 : DirStr="NE"; break;
        case 3 : DirStr="E"; break;
        case 4 : DirStr="SE"; break;
        case 5 : DirStr="S"; break;
        case 6 : DirStr="SW"; break;
        case 7 : DirStr="W"; break;
        case 8 : DirStr="NW"; break;
      }
  fprintf(OutputFile, "(%d,%d) - %s\n", Row, Col, DirStr);
  *match = TRUE;
  return;
}
void main()
{
  int SquareSize;
  int Direction, Found, CheckResult;
  if ((InputFile = fopen("space.in", "r")) == NULL) printf("Coultn't open input\n");
  if ((OutputFile = fopen("space.out", "w")) == NULL) printf("Couldn't open output\n");
  fscanf(InputFile, "%d\n", &SquareSize);
  for (Col=0; Col<=SquareSize+1; Col++) Space[0][Col]=127;
  for (Row=1; Row<=SquareSize; Row++)
  {
    Space[Row][0] = 10;
    for (Col=1; Col<=SquareSize; Col++) fscanf(InputFile, "%c", &Space[Row][Col]);
    fscanf(InputFile, "\n");
    Space[Row][SquareSize+1] = 127;
  }
  for (Col=0; Col<=SquareSize+1; Col++) Space[SquareSize+1][Col]=127;
  for (;;)
  {
    if (fscanf(InputFile, "%s\n", SearchString) == EOF) break;
    fprintf(OutputFile, "\n%s\n", SearchString);
    Found = FALSE;
    for (Row=1; Row<=SquareSize; Row++)
      for (Col=1; Col<=SquareSize; Col++)
        for (Direction=1; Direction<=8; Direction++)
	{
          Check(Row, Col, Direction, &CheckResult);
	  Found = CheckResult || Found;
        }
    if (!Found) fprintf(OutputFile, "not found\n");
  }
  fclose(InputFile);
  fclose(OutputFile);
}
