2008 ACM ICPC Mid-Central USA Regional Programming Contest

To install the judging utilities, open a Command Prompt, change to a
directory for which you have write access, and enter e:\install, where
'e:' is the appropriate letter for your CD drive.

You can browse the contest materials by opening e:\mcpc2008\browse.html
in a web browser.
