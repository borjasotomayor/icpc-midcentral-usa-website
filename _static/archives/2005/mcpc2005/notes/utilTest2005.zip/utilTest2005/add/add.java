// add.java
import java.util.*;
import java.io.*;  // needed for PrintWriter

class add {
  
  public static void main(String[] args) {

//  standard I/O setup follows
    String file = "add.in";
    if (args.length > 0)
        file = args[0]; // for debugging
    Scanner in = null;
    try {
        in = new Scanner(new BufferedReader(  
                         new FileReader(file))); 
    } catch(Exception e) {
        System.err.println("can't open input " + file);
        System.exit(-1);
    }

    int i = in.nextInt();
    int j = in.nextInt();
    while (i != 999) {
        System.out.println(i+j); 
        i = in.nextInt();
        j = in.nextInt();
    }
  }
}
