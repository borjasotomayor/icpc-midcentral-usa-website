#include <iostream>
#include <fstream>

using namespace std;

int main()
{
        
    ifstream cin("add.in");
    int a, b;
    cin >> a;
    while (a != 999) {
        cin >> b;
        cout << (a+b) << endl;
        cin >> a;
    }
    
    return 0;
}

