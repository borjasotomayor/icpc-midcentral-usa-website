ACM Mid-Central Programming Contest 2005 Utility Testing

Testing instructions:
  The judge directory contains the main scripts j1.cmd and j2.cmd.
  See the Utuility instructions and change them as needed for your installation.
  For testing, there is only a problem A, with materials in the directory add.
  The script j.cmd only recognizes probelm A, add.
  For the real contest you will have to replace this j.cmd with the actual one 
     for the contest.
  To test:
     copy add\add.java onto one floppy (or flash drive or whatever you are using).
     copy add\add.cpp onto another floppy or ....
  
  CD to the team directory
  Follow the judging instructions after entering the command
    j a 12
  Switch source media and try again to test the other compiler.

  If you modified j1.cmd or j2.cmd, be sure to overwrite the versions that comes with
  the official contest package.